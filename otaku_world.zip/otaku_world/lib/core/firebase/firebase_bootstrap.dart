import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

import 'firebase_options.dart';

class FirebaseBootstrap {
  FirebaseBootstrap._();

  /// Returns true only when Firebase is really configured AND initialized.
  static Future<bool> init() async {
    if (!DefaultFirebaseOptions.isConfigured) {
      debugPrint('Firebase: not configured, running without backend.');
      return false;
    }
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      return true;
    } catch (e) {
      debugPrint('Firebase init failed: $e');
      return false;
    }
  }
}
