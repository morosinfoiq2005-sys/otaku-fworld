import 'package:firebase_core/firebase_core.dart';

/// PLACEHOLDER. The build workflow replaces this file with real values when the
/// GOOGLE_SERVICES_JSON secret exists. Never put real keys in this file by hand.
class DefaultFirebaseOptions {
  DefaultFirebaseOptions._();

  static const bool isConfigured = false;

  static const FirebaseOptions currentPlatform = FirebaseOptions(
    apiKey: '',
    appId: '',
    messagingSenderId: '',
    projectId: '',
  );
}
