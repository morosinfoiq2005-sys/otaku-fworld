import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../l10n/app_localizations.dart';
import '../providers/app_providers.dart';
import '../theme/app_colors.dart';

/// Round AR/EN switch button.
class LanguageToggle extends ConsumerWidget {
  const LanguageToggle({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bool isAr = ref.watch(localeProvider).languageCode == 'ar';
    return Tooltip(
      message: context.tr('language'),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () => ref.read(localeProvider.notifier).toggle(),
          child: Container(
            width: 48,
            height: 48,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.electricBlue.withAlpha(150)),
            ),
            child: Text(
              isAr ? 'EN' : 'ع',
              style: const TextStyle(
                color: AppColors.electricBlue,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
