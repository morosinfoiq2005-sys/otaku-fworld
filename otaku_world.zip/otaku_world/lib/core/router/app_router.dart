import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/anime/anime_page.dart';
import '../../features/auth/application/auth_controller.dart';
import '../../features/auth/presentation/forgot_password_page.dart';
import '../../features/auth/presentation/loading_page.dart';
import '../../features/auth/presentation/login_page.dart';
import '../../features/auth/presentation/signup_page.dart';
import '../../features/community/community_page.dart';
import '../../features/home/home_page.dart';
import '../../features/marketplace/marketplace_page.dart';
import '../../features/profile/profile_page.dart';
import '../../features/rewards/rewards_page.dart';
import '../../features/shell/main_shell.dart';
import '../../features/themes_studio/themes_studio_page.dart';
import '../../features/wallpapers/wallpapers_page.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey =
    GlobalKey<NavigatorState>(debugLabel: 'root');

const List<String> _authRoutes = ['/login', '/signup', '/forgot'];

GoRouter createRouter({
  required Listenable refresh,
  required AuthStatus Function() readStatus,
}) {
  return GoRouter(
    navigatorKey: _rootNavigatorKey,
    initialLocation: '/',
    refreshListenable: refresh,
    redirect: (BuildContext context, GoRouterState state) {
      final AuthStatus status = readStatus();
      final String loc = state.matchedLocation;
      final bool isAuthRoute = _authRoutes.contains(loc);

      if (status == AuthStatus.loading) {
        return loc == '/loading' ? null : '/loading';
      }
      if (status == AuthStatus.unauthenticated) {
        return isAuthRoute ? null : '/login';
      }
      // guest or authenticated
      if (isAuthRoute || loc == '/loading') return '/';
      return null;
    },
    routes: [
      GoRoute(
        path: '/loading',
        builder: (context, state) => const LoadingPage(),
      ),
      GoRoute(path: '/login', builder: (context, state) => const LoginPage()),
      GoRoute(
        path: '/signup',
        builder: (context, state) => const SignupPage(),
      ),
      GoRoute(
        path: '/forgot',
        builder: (context, state) => const ForgotPasswordPage(),
      ),
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) {
          return MainShell(navigationShell: navigationShell);
        },
        branches: [
          StatefulShellBranch(
            routes: [
              GoRoute(path: '/', builder: (context, state) => const HomePage()),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/wallpapers',
                builder: (context, state) => const WallpapersPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/anime',
                builder: (context, state) => const AnimePage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/rewards',
                builder: (context, state) => const RewardsPage(),
              ),
            ],
          ),
          StatefulShellBranch(
            routes: [
              GoRoute(
                path: '/profile',
                builder: (context, state) => const ProfilePage(),
              ),
            ],
          ),
        ],
      ),
      GoRoute(
        path: '/themes',
        builder: (context, state) => const ThemesStudioPage(),
      ),
      GoRoute(
        path: '/community',
        builder: (context, state) => const CommunityPage(),
      ),
      GoRoute(
        path: '/market',
        builder: (context, state) => const MarketplacePage(),
      ),
    ],
  );
}

final routerProvider = Provider<GoRouter>((ref) {
  final ValueNotifier<int> refresh = ValueNotifier<int>(0);
  ref.listen<AuthState>(authControllerProvider, (previous, next) {
    refresh.value++;
  });
  ref.onDispose(refresh.dispose);
  return createRouter(
    refresh: refresh,
    readStatus: () => ref.read(authControllerProvider).status,
  );
});
