import 'package:flutter/material.dart';

class AppColors {
  AppColors._();

  static const Color background = Color(0xFF05060F);
  static const Color surface = Color(0xFF0C0F24);
  static const Color surfaceHigh = Color(0xFF141838);
  static const Color neonPurple = Color(0xFFA24BFF);
  static const Color electricBlue = Color(0xFF00D1FF);
  static const Color gold = Color(0xFFFFC857);
  static const Color pink = Color(0xFFFF3DA5);
  static const Color textPrimary = Color(0xFFF2F4FF);
  static const Color textSecondary = Color(0xFF9AA1C7);

  static const LinearGradient neonGradient = LinearGradient(
    colors: [neonPurple, electricBlue],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient goldGradient = LinearGradient(
    colors: [gold, Color(0xFFFF8A3D)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
