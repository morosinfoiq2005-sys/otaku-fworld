import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/neon_card.dart';

class _Tile {
  const _Tile(this.icon, this.labelKey, this.color, this.route, this.isTab);

  final IconData icon;
  final String labelKey;
  final Color color;
  final String route;
  final bool isTab;
}

const List<_Tile> _tiles = [
  _Tile(Icons.wallpaper_rounded, 'sec_wallpapers', AppColors.neonPurple,
      '/wallpapers', true),
  _Tile(Icons.palette_rounded, 'sec_themes', AppColors.pink, '/themes', false),
  _Tile(Icons.movie_filter_rounded, 'sec_anime', AppColors.electricBlue,
      '/anime', true),
  _Tile(Icons.emoji_events_rounded, 'sec_rewards', AppColors.gold, '/rewards',
      true),
  _Tile(Icons.groups_rounded, 'sec_community', AppColors.electricBlue,
      '/community', false),
  _Tile(Icons.storefront_rounded, 'sec_market', AppColors.neonPurple,
      '/market', false),
];

class ExploreGrid extends StatelessWidget {
  const ExploreGrid({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.count(
        crossAxisCount: 3,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 1,
        children: [
          for (final _Tile t in _tiles)
            NeonCard(
              glowColor: t.color,
              padding: const EdgeInsets.all(8),
              semanticLabel: context.tr(t.labelKey),
              onTap: () {
                if (t.isTab) {
                  context.go(t.route);
                } else {
                  context.push(t.route);
                }
              },
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(t.icon, color: t.color, size: 30),
                  const SizedBox(height: 8),
                  Text(
                    context.tr(t.labelKey),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
