import 'package:flutter/material.dart';

import '../../../core/data/sample_data.dart';
import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/generative_art.dart';
import '../../../core/widgets/sample_badge.dart';

/// Horizontal list of sample cards (poster/thumbnail + title + tag).
class MediaRail extends StatelessWidget {
  const MediaRail({
    super.key,
    required this.items,
    required this.cardWidth,
    required this.aspectRatio,
    required this.onTap,
  });

  final List<SampleItem> items;
  final double cardWidth;

  /// width / height of the artwork.
  final double aspectRatio;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: cardWidth / aspectRatio + 64,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        separatorBuilder: (BuildContext context, int index) {
          return const SizedBox(width: 12);
        },
        itemBuilder: (BuildContext context, int index) {
          final SampleItem item = items[index];
          return SizedBox(
            width: cardWidth,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: onTap,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    AspectRatio(
                      aspectRatio: aspectRatio,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          GenerativeArt(seed: item.seed, borderRadius: 16),
                          const PositionedDirectional(
                            top: 8,
                            start: 8,
                            child: SampleBadge(),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      item.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 14,
                      ),
                    ),
                    Text(
                      context.tr(item.tagKey),
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
