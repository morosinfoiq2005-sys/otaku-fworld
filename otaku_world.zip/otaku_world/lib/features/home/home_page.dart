import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../core/data/sample_data.dart';
import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/fade_slide_in.dart';
import '../../core/widgets/neon_card.dart';
import '../../core/widgets/section_header.dart';
import '../auth/application/auth_controller.dart';
import 'widgets/explore_grid.dart';
import 'widgets/featured_carousel.dart';
import 'widgets/home_header.dart';
import 'widgets/media_rail.dart';
import 'widgets/rewards_card.dart';

class HomePage extends ConsumerWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final String? userName = ref.watch(authControllerProvider).user?.displayName;
    final String welcome = (userName != null && userName.isNotEmpty)
        ? context.tr('welcome_name').replaceAll('{name}', userName)
        : context.tr('welcome_title');

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.only(bottom: 28),
        children: [
          const FadeSlideIn(child: HomeHeader()),
          FadeSlideIn(
            delay: 80,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: NeonCard(
                child: Row(
                  children: [
                    Container(
                      width: 52,
                      height: 52,
                      decoration: const BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: AppColors.neonGradient,
                      ),
                      child: const Icon(
                        Icons.auto_awesome_rounded,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            welcome,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            context.tr('welcome_sub'),
                            style: const TextStyle(
                              fontSize: 13,
                              color: AppColors.textSecondary,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          SectionHeader(
            title: context.tr('featured_wallpapers'),
            actionLabel: context.tr('view_all'),
            onAction: () => context.go('/wallpapers'),
          ),
          const FadeSlideIn(delay: 120, child: FeaturedCarousel()),
          SectionHeader(title: context.tr('explore_sections')),
          const FadeSlideIn(delay: 160, child: ExploreGrid()),
          SectionHeader(
            title: context.tr('trending_anime'),
            actionLabel: context.tr('view_all'),
            onAction: () => context.go('/anime'),
          ),
          MediaRail(
            items: sampleAnime,
            cardWidth: 128,
            aspectRatio: 2 / 3,
            onTap: () => context.go('/anime'),
          ),
          SectionHeader(
            title: context.tr('popular_themes'),
            actionLabel: context.tr('view_all'),
            onAction: () => context.push('/themes'),
          ),
          MediaRail(
            items: sampleThemes,
            cardWidth: 150,
            aspectRatio: 3 / 4,
            onTap: () => context.push('/themes'),
          ),
          SectionHeader(title: context.tr('daily_rewards')),
          const RewardsCard(),
          SectionHeader(
            title: context.tr('community_highlights'),
            actionLabel: context.tr('view_all'),
            onAction: () => context.push('/community'),
          ),
          MediaRail(
            items: sampleCommunity,
            cardWidth: 150,
            aspectRatio: 1,
            onTap: () => context.push('/community'),
          ),
          SectionHeader(
            title: context.tr('creator_market'),
            actionLabel: context.tr('view_all'),
            onAction: () => context.push('/market'),
          ),
          MediaRail(
            items: sampleMarket,
            cardWidth: 150,
            aspectRatio: 1,
            onTap: () => context.push('/market'),
          ),
        ],
      ),
    );
  }
}
