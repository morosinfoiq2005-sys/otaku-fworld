import 'package:flutter/material.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/neon_background.dart';
import '../../core/widgets/phase_placeholder.dart';

class CommunityPage extends StatelessWidget {
  const CommunityPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: Text(context.tr('sec_community'))),
      body: const NeonBackground(
        child: PhasePlaceholder(
          icon: Icons.groups_rounded,
          titleKey: 'sec_community',
          descKey: 'desc_community',
          phase: 6,
          featureKeys: ['f_com_1', 'f_com_2', 'f_com_3', 'f_com_4'],
          accent: AppColors.electricBlue,
        ),
      ),
    );
  }
}
