import 'package:flutter/material.dart';

import '../../core/theme/app_colors.dart';
import '../../core/widgets/phase_placeholder.dart';

class AnimePage extends StatelessWidget {
  const AnimePage({super.key});

  @override
  Widget build(BuildContext context) {
    return const PhasePlaceholder(
      icon: Icons.movie_filter_rounded,
      titleKey: 'sec_anime',
      descKey: 'desc_anime',
      phase: 4,
      featureKeys: ['f_anime_1', 'f_anime_2', 'f_anime_3', 'f_anime_4', 'f_anime_5', 'f_anime_6'],
      accent: AppColors.electricBlue,
    );
  }
}
