import 'package:flutter/material.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/neon_background.dart';
import '../../core/widgets/phase_placeholder.dart';

class ThemesStudioPage extends StatelessWidget {
  const ThemesStudioPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(title: Text(context.tr('sec_themes'))),
      body: const NeonBackground(
        child: PhasePlaceholder(
          icon: Icons.palette_rounded,
          titleKey: 'sec_themes',
          descKey: 'desc_themes',
          phase: 3,
          featureKeys: ['f_theme_1', 'f_theme_2', 'f_theme_3', 'f_theme_4', 'f_theme_5'],
          accent: AppColors.pink,
        ),
      ),
    );
  }
}
