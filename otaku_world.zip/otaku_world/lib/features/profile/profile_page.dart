import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/l10n/app_localizations.dart';
import '../../core/providers/app_providers.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/fade_slide_in.dart';
import '../../core/widgets/neon_card.dart';
import '../../core/widgets/section_header.dart';
import '../auth/application/auth_controller.dart';
import '../auth/presentation/widgets/auth_widgets.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final Locale locale = ref.watch(localeProvider);
    final AuthState auth = ref.watch(authControllerProvider);
    final bool backendReady = ref.watch(authRepositoryProvider).isAvailable;
    final bool isGuest = auth.status == AuthStatus.guest;

    final String? name = auth.user?.displayName;
    final String title = (name != null && name.isNotEmpty)
        ? name
        : (auth.user?.email ?? context.tr('guest'));
    final String subtitle = isGuest
        ? context.tr('guest_note')
        : (auth.user?.email ?? '');

    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          FadeSlideIn(
            child: NeonCard(
              child: Row(
                children: [
                  Container(
                    width: 64,
                    height: 64,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      gradient: AppColors.neonGradient,
                    ),
                    child: const Icon(
                      Icons.person_rounded,
                      size: 34,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppColors.textSecondary,
                            height: 1.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          FadeSlideIn(
            delay: 40,
            child: isGuest
                ? GradientButton(
                    label: context.tr('sign_in_or_up'),
                    onPressed: () =>
                        ref.read(authControllerProvider.notifier).signOut(),
                  )
                : OutlinedButton.icon(
                    style: OutlinedButton.styleFrom(
                      minimumSize: const Size.fromHeight(50),
                      side: const BorderSide(color: AppColors.pink),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14),
                      ),
                    ),
                    onPressed: () =>
                        ref.read(authControllerProvider.notifier).signOut(),
                    icon: const Icon(Icons.logout_rounded, color: AppColors.pink),
                    label: Text(
                      context.tr('sign_out'),
                      style: const TextStyle(color: AppColors.pink),
                    ),
                  ),
          ),
          SectionHeader(title: context.tr('language')),
          FadeSlideIn(
            delay: 80,
            child: NeonCard(
              glowColor: AppColors.electricBlue,
              child: SizedBox(
                width: double.infinity,
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment<String>(value: 'ar', label: Text('العربية')),
                    ButtonSegment<String>(value: 'en', label: Text('English')),
                  ],
                  selected: {locale.languageCode},
                  onSelectionChanged: (Set<String> selection) {
                    ref
                        .read(localeProvider.notifier)
                        .setLocale(Locale(selection.first));
                  },
                ),
              ),
            ),
          ),
          SectionHeader(title: context.tr('backend_status')),
          FadeSlideIn(
            delay: 120,
            child: NeonCard(
              glowColor: backendReady ? AppColors.electricBlue : AppColors.gold,
              child: Row(
                children: [
                  Icon(
                    backendReady
                        ? Icons.cloud_done_rounded
                        : Icons.cloud_off_rounded,
                    color: backendReady
                        ? AppColors.electricBlue
                        : AppColors.gold,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      context.tr(
                        backendReady
                            ? 'backend_connected'
                            : 'backend_not_connected',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          SectionHeader(title: context.tr('about')),
          FadeSlideIn(
            delay: 160,
            child: NeonCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: AppColors.electricBlue,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '${context.tr('version')}: ${context.tr('version_value')}',
                          style: const TextStyle(fontWeight: FontWeight.w700),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(
                    context.tr('about_text'),
                    style: const TextStyle(
                      color: AppColors.textSecondary,
                      height: 1.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
