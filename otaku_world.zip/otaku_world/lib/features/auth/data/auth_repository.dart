import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

class AppUser {
  const AppUser({required this.uid, this.email, this.displayName});

  final String uid;
  final String? email;
  final String? displayName;
}

/// Carries a localization key for the error message.
class AuthFailure implements Exception {
  const AuthFailure(this.key);

  final String key;
}

abstract class AuthRepository {
  bool get isAvailable;
  Stream<AppUser?> userChanges();
  Future<void> signIn(String email, String password);
  Future<void> signUp(String name, String email, String password);
  Future<void> sendPasswordReset(String email);
  Future<void> signOut();
}

/// Used when Firebase is not configured. Never pretends to work.
class UnavailableAuthRepository implements AuthRepository {
  @override
  bool get isAvailable => false;

  @override
  Stream<AppUser?> userChanges() => const Stream<AppUser?>.empty();

  @override
  Future<void> signIn(String email, String password) {
    throw const AuthFailure('err_backend_unavailable');
  }

  @override
  Future<void> signUp(String name, String email, String password) {
    throw const AuthFailure('err_backend_unavailable');
  }

  @override
  Future<void> sendPasswordReset(String email) {
    throw const AuthFailure('err_backend_unavailable');
  }

  @override
  Future<void> signOut() async {}
}

class FirebaseAuthRepository implements AuthRepository {
  FirebaseAuthRepository(this._auth, this._db);

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  @override
  bool get isAvailable => true;

  AppUser? _map(User? user) {
    if (user == null) return null;
    return AppUser(
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
    );
  }

  @override
  Stream<AppUser?> userChanges() => _auth.userChanges().map(_map);

  String _errorKey(String code) {
    switch (code) {
      case 'invalid-email':
        return 'err_invalid_email';
      case 'user-not-found':
      case 'wrong-password':
      case 'invalid-credential':
        return 'err_wrong_credentials';
      case 'email-already-in-use':
        return 'err_email_in_use';
      case 'weak-password':
        return 'err_weak_password';
      case 'network-request-failed':
        return 'err_network';
      case 'too-many-requests':
        return 'err_too_many';
      default:
        return 'err_generic';
    }
  }

  @override
  Future<void> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_errorKey(e.code));
    } catch (_) {
      throw const AuthFailure('err_generic');
    }
  }

  @override
  Future<void> signUp(String name, String email, String password) async {
    try {
      final UserCredential cred = await _auth.createUserWithEmailAndPassword(
        email: email.trim(),
        password: password,
      );
      final User? user = cred.user;
      if (user == null) throw const AuthFailure('err_generic');
      await user.updateDisplayName(name.trim());
      try {
        await _db.collection('users').doc(user.uid).set({
          'displayName': name.trim(),
          'email': email.trim(),
          'createdAt': FieldValue.serverTimestamp(),
          'points': 0,
          'level': 1,
          'role': 'user',
        });
      } catch (e) {
        // Usually means Firestore rules are not published yet.
        debugPrint('Could not create user profile document: $e');
      }
    } on FirebaseAuthException catch (e) {
      throw AuthFailure(_errorKey(e.code));
    } on AuthFailure {
      rethrow;
    } catch (_) {
      throw const AuthFailure('err_generic');
    }
  }

  @override
  Future<void> sendPasswordReset(String email) async {
    try {
      await _auth.sendPasswordResetEmail(email: email.trim());
    } on FirebaseAuthException catch (e) {
      // Do not reveal whether an email exists.
      if (e.code == 'user-not-found') return;
      throw AuthFailure(_errorKey(e.code));
    } catch (_) {
      throw const AuthFailure('err_generic');
    }
  }

  @override
  Future<void> signOut() => _auth.signOut();
}
