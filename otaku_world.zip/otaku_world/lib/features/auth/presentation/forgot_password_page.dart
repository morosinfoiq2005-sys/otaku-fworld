import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/l10n/app_localizations.dart';
import '../application/auth_controller.dart';
import 'widgets/auth_widgets.dart';

class ForgotPasswordPage extends ConsumerStatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  ConsumerState<ForgotPasswordPage> createState() =>
      _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends ConsumerState<ForgotPasswordPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  bool _loading = false;
  bool _sent = false;
  String? _errorKey;

  @override
  void dispose() {
    _email.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _loading = true;
      _errorKey = null;
      _sent = false;
    });
    final String? error = await ref
        .read(authControllerProvider.notifier)
        .sendPasswordReset(_email.text);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _errorKey = error;
      _sent = error == null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool available = ref.watch(authRepositoryProvider).isAvailable;

    return AuthScaffold(
      titleKey: 'forgot_title',
      subtitleKey: 'forgot_sub',
      showBack: true,
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (!available)
              AuthBanner(
                message: context.tr('auth_backend_off'),
                isError: false,
              ),
            if (_errorKey != null) AuthBanner(message: context.tr(_errorKey!)),
            if (_sent)
              AuthBanner(message: context.tr('reset_sent'), isError: false),
            AuthField(
              controller: _email,
              labelKey: 'email',
              icon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
              textInputAction: TextInputAction.done,
              onSubmitted: available ? _submit : null,
              validator: (String? v) => Validators.email(context, v),
            ),
            const SizedBox(height: 20),
            GradientButton(
              label: context.tr('send_reset'),
              loading: _loading,
              onPressed: available ? _submit : null,
            ),
          ],
        ),
      ),
    );
  }
}
