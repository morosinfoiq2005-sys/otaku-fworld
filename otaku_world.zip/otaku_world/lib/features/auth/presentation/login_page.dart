import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../application/auth_controller.dart';
import 'widgets/auth_widgets.dart';

class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends ConsumerState<LoginPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  bool _loading = false;
  String? _errorKey;

  @override
  void dispose() {
    _email.dispose();
    _password.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _loading = true;
      _errorKey = null;
    });
    final String? error = await ref
        .read(authControllerProvider.notifier)
        .signIn(_email.text, _password.text);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _errorKey = error;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool available = ref.watch(authRepositoryProvider).isAvailable;

    return AuthScaffold(
      titleKey: 'login_title',
      subtitleKey: 'login_sub',
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (!available)
              AuthBanner(
                message: context.tr('auth_backend_off'),
                isError: false,
              ),
            if (_errorKey != null) AuthBanner(message: context.tr(_errorKey!)),
            AuthField(
              controller: _email,
              labelKey: 'email',
              icon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
              validator: (String? v) => Validators.email(context, v),
            ),
            const SizedBox(height: 12),
            AuthField(
              controller: _password,
              labelKey: 'password',
              icon: Icons.lock_outline_rounded,
              obscure: true,
              textInputAction: TextInputAction.done,
              onSubmitted: available ? _submit : null,
              validator: (String? v) => Validators.password(context, v),
            ),
            Align(
              alignment: AlignmentDirectional.centerEnd,
              child: TextButton(
                onPressed: () => context.go('/forgot'),
                child: Text(context.tr('forgot_password')),
              ),
            ),
            const SizedBox(height: 4),
            GradientButton(
              label: context.tr('sign_in'),
              loading: _loading,
              onPressed: available ? _submit : null,
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(child: Divider(color: AppColors.surfaceHigh)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Text(
                    context.tr('or_label'),
                    style: const TextStyle(color: AppColors.textSecondary),
                  ),
                ),
                const Expanded(child: Divider(color: AppColors.surfaceHigh)),
              ],
            ),
            const SizedBox(height: 16),
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                minimumSize: const Size.fromHeight(50),
                side: const BorderSide(color: AppColors.electricBlue),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              onPressed: () =>
                  ref.read(authControllerProvider.notifier).continueAsGuest(),
              child: Text(
                context.tr('continue_guest'),
                style: const TextStyle(color: AppColors.electricBlue),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  context.tr('no_account'),
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                TextButton(
                  onPressed: () => context.go('/signup'),
                  child: Text(context.tr('sign_up')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
