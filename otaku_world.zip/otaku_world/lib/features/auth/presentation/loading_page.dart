import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/neon_background.dart';

class LoadingPage extends StatelessWidget {
  const LoadingPage({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: NeonBackground(
        child: Center(
          child: CircularProgressIndicator(color: AppColors.electricBlue),
        ),
      ),
    );
  }
}
