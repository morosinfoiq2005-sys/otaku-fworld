import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/l10n/app_localizations.dart';
import '../../../core/theme/app_colors.dart';
import '../application/auth_controller.dart';
import 'widgets/auth_widgets.dart';

class SignupPage extends ConsumerStatefulWidget {
  const SignupPage({super.key});

  @override
  ConsumerState<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends ConsumerState<SignupPage> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _name = TextEditingController();
  final TextEditingController _email = TextEditingController();
  final TextEditingController _password = TextEditingController();
  final TextEditingController _confirm = TextEditingController();
  bool _loading = false;
  String? _errorKey;

  @override
  void dispose() {
    _name.dispose();
    _email.dispose();
    _password.dispose();
    _confirm.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    setState(() {
      _loading = true;
      _errorKey = null;
    });
    final String? error = await ref
        .read(authControllerProvider.notifier)
        .signUp(_name.text, _email.text, _password.text);
    if (!mounted) return;
    setState(() {
      _loading = false;
      _errorKey = error;
    });
  }

  @override
  Widget build(BuildContext context) {
    final bool available = ref.watch(authRepositoryProvider).isAvailable;

    return AuthScaffold(
      titleKey: 'signup_title',
      subtitleKey: 'signup_sub',
      showBack: true,
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (!available)
              AuthBanner(
                message: context.tr('auth_backend_off'),
                isError: false,
              ),
            if (_errorKey != null) AuthBanner(message: context.tr(_errorKey!)),
            AuthField(
              controller: _name,
              labelKey: 'full_name',
              icon: Icons.person_outline_rounded,
              validator: (String? v) => Validators.name(context, v),
            ),
            const SizedBox(height: 12),
            AuthField(
              controller: _email,
              labelKey: 'email',
              icon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
              validator: (String? v) => Validators.email(context, v),
            ),
            const SizedBox(height: 12),
            AuthField(
              controller: _password,
              labelKey: 'password',
              icon: Icons.lock_outline_rounded,
              obscure: true,
              validator: (String? v) => Validators.password(context, v),
            ),
            const SizedBox(height: 12),
            AuthField(
              controller: _confirm,
              labelKey: 'confirm_password',
              icon: Icons.lock_reset_rounded,
              obscure: true,
              textInputAction: TextInputAction.done,
              onSubmitted: available ? _submit : null,
              validator: (String? v) {
                if (v != _password.text) return context.tr('val_match');
                return null;
              },
            ),
            const SizedBox(height: 20),
            GradientButton(
              label: context.tr('sign_up'),
              loading: _loading,
              onPressed: available ? _submit : null,
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  context.tr('have_account'),
                  style: const TextStyle(color: AppColors.textSecondary),
                ),
                TextButton(
                  onPressed: () => context.go('/login'),
                  child: Text(context.tr('sign_in')),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
