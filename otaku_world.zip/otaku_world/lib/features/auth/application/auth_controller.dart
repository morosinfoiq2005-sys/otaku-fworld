import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/providers/app_providers.dart';
import '../data/auth_repository.dart';

enum AuthStatus { loading, unauthenticated, guest, authenticated }

class AuthState {
  const AuthState(this.status, [this.user]);

  final AuthStatus status;
  final AppUser? user;
}

final authRepositoryProvider = Provider<AuthRepository>((ref) {
  if (ref.watch(firebaseReadyProvider)) {
    return FirebaseAuthRepository(
      FirebaseAuth.instance,
      FirebaseFirestore.instance,
    );
  }
  return UnavailableAuthRepository();
});

class AuthController extends Notifier<AuthState> {
  static const String _guestKey = 'guest_mode';
  StreamSubscription<AppUser?>? _sub;

  AuthRepository get _repo => ref.read(authRepositoryProvider);

  bool get _isGuest =>
      ref.read(sharedPreferencesProvider).getBool(_guestKey) ?? false;

  @override
  AuthState build() {
    ref.onDispose(() => _sub?.cancel());

    if (!_repo.isAvailable) {
      return _isGuest
          ? const AuthState(AuthStatus.guest)
          : const AuthState(AuthStatus.unauthenticated);
    }

    _sub = _repo.userChanges().listen((AppUser? user) {
      if (user != null) {
        state = AuthState(AuthStatus.authenticated, user);
      } else {
        state = _isGuest
            ? const AuthState(AuthStatus.guest)
            : const AuthState(AuthStatus.unauthenticated);
      }
    });
    return const AuthState(AuthStatus.loading);
  }

  Future<void> _setGuest(bool value) {
    return ref.read(sharedPreferencesProvider).setBool(_guestKey, value);
  }

  /// Returns null on success, or a localization key describing the error.
  Future<String?> _run(Future<void> Function() action) async {
    try {
      await action();
      await _setGuest(false);
      return null;
    } on AuthFailure catch (e) {
      return e.key;
    } catch (_) {
      return 'err_generic';
    }
  }

  Future<String?> signIn(String email, String password) {
    return _run(() => _repo.signIn(email, password));
  }

  Future<String?> signUp(String name, String email, String password) {
    return _run(() => _repo.signUp(name, email, password));
  }

  Future<String?> sendPasswordReset(String email) async {
    try {
      await _repo.sendPasswordReset(email);
      return null;
    } on AuthFailure catch (e) {
      return e.key;
    } catch (_) {
      return 'err_generic';
    }
  }

  Future<void> continueAsGuest() async {
    await _setGuest(true);
    state = const AuthState(AuthStatus.guest);
  }

  /// Signs out a real user, or leaves guest mode.
  Future<void> signOut() async {
    await _setGuest(false);
    if (state.status == AuthStatus.authenticated) {
      await _repo.signOut();
    } else {
      state = const AuthState(AuthStatus.unauthenticated);
    }
  }
}

final authControllerProvider =
    NotifierProvider<AuthController, AuthState>(AuthController.new);
