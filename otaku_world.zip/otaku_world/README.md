# OTAKU WORLD

Your Anime. Your Style. Your Rewards.

Flutter (Android first) - Arabic RTL + English - Neon Cyberpunk dark theme.

## Status
- Phase 1: foundation, theme, localization, navigation, home screen  (done)
- Auth step: login / sign up / forgot password / guest mode, Firebase Auth +
  Firestore user profile, auth-guarded routes, real profile page   (done)
- Everything else is clearly marked "planned" in the app.

## Firebase
Not connected until you add the GOOGLE_SERVICES_JSON secret. See docs/FIREBASE_SETUP.md.
Security rules: firestore.rules (points/level/role cannot be changed by users).

Rewards policy: there is NO cash withdrawal feature in this app.

## Roadmap
2 Wallpapers - 3 Themes Studio - 4 Anime & Cinema - 5 Rewards - 6 Community
7 Creator Marketplace - 8 Backend hardening + admin - 9 Testing and release
