# Firebase setup (from an Android phone)

1. Open https://console.firebase.google.com and create a project (e.g. otaku-world).
2. Add an Android app. Package name MUST be: com.otakuworld.otaku_world
3. Download google-services.json.
4. Build > Authentication > Get started > Sign-in method > enable "Email/Password".
5. Build > Firestore Database > Create database (production mode), then open the
   "Rules" tab, replace everything with the content of firestore.rules, and Publish.
6. In GitHub: Settings > Secrets and variables > Actions > New repository secret
   Name: GOOGLE_SERVICES_JSON   Value: the full content of google-services.json
7. Actions > Build APK > Run workflow. The new APK is connected to Firebase.

To make someone an admin: in Firestore create collection "admins" with a document
whose ID is that user's UID (visible in Authentication > Users).
Admin rights are checked by Firestore rules on the server, not only in the app.

Google Sign-In is NOT enabled yet (it needs a fixed signing key + SHA-1).
